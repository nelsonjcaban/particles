#pragma once

#include "ofMain.h"
#include "Particle.h"


class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();
		void resetParticles();

		void keyPressed  (int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		
		particleMode currentMode;
		string currentModeStr; 

		vector <Particle> p;
		vector <glm::vec3> attractPoints;
		vector <glm::vec3> attractPointsWithMovement;
		glm::vec3 vel;
		ofColor currentColor;
		ofColor red = ofColor(255,0,0);
		ofColor blue = ofColor(0,0,255);
		ofColor yellow = ofColor(255,255,0);
		ofColor chosen = ofColor(255,165,0);
		ofColor default1 = ofColor(255,63,180);
		ofColor default2 = ofColor(208,255,63);
		ofColor default3 = ofColor(99,63,255);
		ofColor default4 = ofColor(103,160,237);
		ofRectangle rect;
		int countC = 0;
		int countP = 0;
		int countR = 0;
		int countRep = 0;
		int replay = 0;
		int repx = 10;
		int recPos = 0;
		bool pause = false;
		bool isDragging;
		ofVec2f dragStart;
		bool isRecording = false;
		bool isReplay = false;
		vector<char> rec;
};

