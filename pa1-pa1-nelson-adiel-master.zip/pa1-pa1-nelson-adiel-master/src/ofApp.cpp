#include "ofApp.h"
#include "Particle.h"
using namespace::std;

//--------------------------------------------------------------
void ofApp::setup(){
	ofSetVerticalSync(true);
	
	int num = 1500;
	p.assign(num, Particle());
	currentMode = PARTICLE_MODE_ATTRACT;

	currentModeStr = "1 - PARTICLE_MODE_ATTRACT: attracts to mouse"; 

	resetParticles();
	//sets default state of mouse to not be dragging//
	isDragging = false;
}

//--------------------------------------------------------------
void ofApp::resetParticles(){

	//these are the attraction points used in the fourth demo 
	attractPoints.clear();
	for(int i = 0; i < 4; i++){
		attractPoints.push_back( glm::vec3( ofMap(i, 0, 4, 100, ofGetWidth()-100) , ofRandom(100, ofGetHeight()-100) , 0) );
	}
	
	attractPointsWithMovement = attractPoints;
	
	for(unsigned int i = 0; i < p.size(); i++){
		p[i].setMode(currentMode);		
		p[i].setAttractPoints(&attractPointsWithMovement);;
		p[i].reset();
	}	
}

//--------------------------------------------------------------
void ofApp::update(){
	if(currentColor == chosen){
		ofNoFill();
	}
	if(currentColor != chosen){
		ofFill();
	}
	if(pause == false){
		for(unsigned int i = 0; i < p.size(); i++){
			if (countC == 5 || countC == 0){
				if( currentMode == PARTICLE_MODE_ATTRACT ){
					currentColor = default1; 
				}
				else if( currentMode == PARTICLE_MODE_REPEL ){
					currentColor = default2;
				}
				else if( currentMode == PARTICLE_MODE_NOISE ){
					currentColor = default3;
				}
				else if( currentMode == PARTICLE_MODE_NEAREST_POINTS ){
					currentColor = default4;
				}
				p[i].setMode(currentMode);
	


			}
			p[i].setMode(currentMode);
			p[i].update();
		}
	
	//lets add a bit of movement to the attract points
		for(unsigned int i = 0; i < attractPointsWithMovement.size(); i++){
			attractPointsWithMovement[i].x = attractPoints[i].x + ofSignedNoise(i * 10, ofGetElapsedTimef() * 0.7) * 12.0;
			attractPointsWithMovement[i].y = attractPoints[i].y + ofSignedNoise(i * -10, ofGetElapsedTimef() * 0.7) * 12.0;
		}	
		for (unsigned int i = 0; i < p.size(); i++){
			if (rect.inside(p[i].getX(), p[i].getY())){
				p[i].scale = p[i].originalsize * 5.0;
			}
			else {
				p[i].scale = p[i].originalsize;
			}
			p[i].update();
		}
	}
	if (replay % 360 == 0 && isReplay == true && rec.size() >= 1){
		if (rec[recPos] == '1')
		{
		currentMode = PARTICLE_MODE_ATTRACT;
		currentModeStr = "1 - PARTICLE_MODE_ATTRACT: attracts to mouse";
		}
		if(rec[recPos] == '2'){
		currentMode = PARTICLE_MODE_REPEL;
		currentModeStr = "2 - PARTICLE_MODE_REPEL: repels from mouse";
		}
		if(rec[recPos] == '3'){
		currentMode = PARTICLE_MODE_NEAREST_POINTS;
		currentModeStr = "3 - PARTICLE_MODE_NEAREST_POINTS: hold 'f' to disable force"; 
		}
		if(rec[recPos] == '4'){
		currentMode = PARTICLE_MODE_NOISE;
		currentModeStr = "4 - PARTICLE_MODE_NOISE: snow particle simulation";
		}
		if(rec[recPos] == 't'){
			countC+= 1;
		//firstTime = 0;
		if (countC == 1){ //blue
		 currentColor = blue;
		}
		if (countC == 2){ //yellow
		 currentColor = yellow;

		}
		if (countC == 3){ //red
		 currentColor = red;

		}
		if (countC == 4){ //chosen color
		 currentColor = chosen;
		}
		if (countC == 5 || countC == 0){ //default color
			if( currentMode == PARTICLE_MODE_ATTRACT ){
				currentColor = default1; 
			}
			else if( currentMode == PARTICLE_MODE_REPEL ){
				currentColor = default2;
			}
			else if( currentMode == PARTICLE_MODE_NOISE ){
				currentColor = default3;
			}
			else if( currentMode == PARTICLE_MODE_NEAREST_POINTS ){
				currentColor = default4;
			}
			countC = 0;
		}
		}
		if(rec[recPos] == 'a'){
			for(unsigned int i = 0; i < p.size(); i++){
			p[i].speed /= 2;
		}
		}
		if (rec[recPos] == 'd')
		{
			for(unsigned int i = 0; i < p.size(); i++){
			p[i].speed *= 2;
		}
		}
		if (rec[recPos] == 's')
		{
			if(countP == 0){
			pause = true;
			countP = 1;
		}
		else if(countP  == 1){
			pause = false;
			countP = 0;
		}
		}
		if (rec[recPos] == ' '){
			resetParticles();
		}
		
		
		recPos += 1;
		repx += 10;
		if(recPos > rec.size()){
			isReplay = false;
			recPos  = 0;
			repx = 10;
			replay = 0;
			rec.clear();
		}
	}
	replay ++;	
}

//--------------------------------------------------------------
void ofApp::draw(){
    	ofBackgroundGradient(ofColor(60,60,60), ofColor(10,10,10)); //60 60 60

		if(isRecording == true && isReplay == false){
			ofSetColor(255, 0, 0);  // Set fill color to red (255,0,0)
			ofDrawBitmapString("recording...",ofGetWidth()-150,ofGetHeight()-28);
		}

		if(isReplay == true && isRecording == false){
			ofSetColor(255, 255, 255);  // Set fill color to red (255,0,0)
			ofDrawBitmapString("replaying...",ofGetWidth()-150,ofGetHeight()-28);
		}
		for(unsigned int i = 0; i < p.size(); i++){
			ofSetColor(currentColor);
			p[i].draw();
		}

		ofSetColor(190); //190
		if( currentMode == PARTICLE_MODE_NEAREST_POINTS ){
			for(unsigned int i = 0; i < attractPoints.size(); i++){
				ofNoFill();
				ofDrawCircle(attractPointsWithMovement[i], 10);
				ofFill();
				ofDrawCircle(attractPointsWithMovement[i], 4);
			}
		}
		ofSetColor(230);	//230
		ofDrawBitmapString(currentModeStr + "\n\nSpacebar to reset. \nKeys 1-4 to change mode.", 10, 20);
		//sets color of rectangle to be white with 50% transparency//
		ofSetColor(255,128);
		ofDrawRectangle(rect);
		if(isReplay == true && rec.size() >= 1){
			ofDrawBitmapString(rec[recPos-1],repx,80);
		}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	if( key == '1' && pause == false && isReplay == false){
		currentMode = PARTICLE_MODE_ATTRACT;
		currentModeStr = "1 - PARTICLE_MODE_ATTRACT: attracts to mouse";
		if (isRecording == true){
			rec.push_back(key);
		}
	}
	if( key == '2' && pause == false && isReplay == false){
		currentMode = PARTICLE_MODE_REPEL;
		currentModeStr = "2 - PARTICLE_MODE_REPEL: repels from mouse"; 
		if (isRecording == true){
			rec.push_back(key);
		}		
	}
	if( key == '3' && pause == false && isReplay == false){
		currentMode = PARTICLE_MODE_NEAREST_POINTS;
		currentModeStr = "3 - PARTICLE_MODE_NEAREST_POINTS: hold 'f' to disable force"; 
		if (isRecording == true){
			rec.push_back(key);
		}						
	}
	if( key == '4' && pause == false && isReplay == false){
		currentMode = PARTICLE_MODE_NOISE;
		currentModeStr = "4 - PARTICLE_MODE_NOISE: snow particle simulation";
		if (isRecording == true){
			rec.push_back(key);
		} 						
		resetParticles();
	}	
		
	if( key == ' ' && pause == false && isReplay == false){
		if (isRecording == true){
			rec.push_back(key);
		}
		resetParticles();
	}
	if (key == 't' && pause == false && isReplay == false){
		if (isRecording == true){
			rec.push_back(key);
		}
		countC+= 1;
		//firstTime = 0;
		if (countC == 1){ //blue
		 currentColor = blue;
		}
		if (countC == 2){ //yellow
		 currentColor = yellow;

		}
		if (countC == 3){ //red
		 currentColor = red;

		}
		if (countC == 4){ //chosen color
		 currentColor = chosen;
		}
		if (countC == 5 || countC == 0){ //default color
			if( currentMode == PARTICLE_MODE_ATTRACT ){
				currentColor = default1; 
			}
			else if( currentMode == PARTICLE_MODE_REPEL ){
				currentColor = default2;
			}
			else if( currentMode == PARTICLE_MODE_NOISE ){
				currentColor = default3;
			}
			else if( currentMode == PARTICLE_MODE_NEAREST_POINTS ){
				currentColor = default4;
			}
			countC = 0;
		}
	}
	if(key == 'd' && isReplay == false){
		for(unsigned int i = 0; i < p.size(); i++){
			p[i].speed *= 2;
		}
		if (isRecording == true){
			rec.push_back(key);
		}
	}
	if(key == 'a' && isReplay == false){
		for(unsigned int i = 0; i < p.size(); i++){
			p[i].speed /= 2;
		}
		if (isRecording == true){
			rec.push_back(key);
		}
	}
	if (key == 's' && isReplay == false){
		if (isRecording == true){
			rec.push_back(key);
		}
		if(countP == 0){
			pause = true;
			countP = 1;
		}
		else if(countP  == 1){
			pause = false;
			countP = 0;
		}
	}
	if (key == 'r' && isReplay == false){
		if (countR == 0){
			isRecording = true;
			countR = 1;
		}
		else if(countR == 1){
			isRecording = false;
			countR = 0;
		}
	}
	if (key == 'p' && isRecording == false){
		isReplay = true;
	}
	if(key == 'c'){
		isReplay = false;
		replay = 0;
		recPos = 0;
		repx = 10;
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
if (button == 0 && isDragging) 
{	
	// Calculates width and height of rectangle based on how far the mouse is dragged
	int width = x - dragStart.x;
	int height = y - dragStart.y;

	rect.setWidth(width);
	rect.setHeight(height);
}
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
if (button == 0 && !isDragging)
{
	isDragging = true;
	dragStart.set(x,y);
	rect.set(x,y,0,0);
}
else if (button == 2)
{
	if (rect.inside(x,y))
	{
		rect.set(0,0,0,0);
	}
	
}


}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
if (button == 0 && isDragging)
{	
	// changes state of mouse to not dragging when mouse is released
	isDragging = false;
}

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

