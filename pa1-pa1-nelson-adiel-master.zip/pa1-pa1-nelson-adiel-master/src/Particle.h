#pragma once
#include "ofMain.h"


enum particleMode{
	PARTICLE_MODE_ATTRACT = 0,
	PARTICLE_MODE_REPEL,
	PARTICLE_MODE_NEAREST_POINTS,
	PARTICLE_MODE_NOISE
};

class Particle{

	public:
		Particle();
		
		void setMode(particleMode newMode);	
		void setAttractPoints( vector <glm::vec3> * attract );
		void attractToPoint(int, int);
		void repelFromPoint(int, int);
		void reset();
		void update();
		void draw();
		//setter
		void setOriginalsize(float scale){
			originalsize = scale;
			this->scale = scale;

		}		
		glm::vec3 pos;
		glm::vec3 vel;
		glm::vec3 frc;
		
		float drag; 
		float uniqueVal;
		float scale;
		float originalsize;
		float getX() const { return pos.x; }
		float getY() const { return pos.y; }
	
		particleMode mode;
		
		vector <glm::vec3> * attractPoints; 
		float speed;
};
